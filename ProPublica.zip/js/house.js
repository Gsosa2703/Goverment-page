 var membersHouse = datos.results[0].members;
 console.log(membersHouse);


imprimirTabla(membersHouse);
function imprimirTabla(listaDeMiembros) {
  document.getElementById("house-data").innerHTML = tablaHouse(listaDeMiembros);
}

//Dibujo la tabla 
function tablaHouse(listaDeMiembros) {
  var listaFinal = "";
  for (i = 0; i < listaDeMiembros.length; i++) {
    listaFinal += "<tr>" + "<td>" + i + "</td>" + "<td>" + "<a href=" + listaDeMiembros[i].url + ">" + listaDeMiembros[i].first_name + ", " + listaDeMiembros[i].last_name + "</a>" + "</td>" +
      "<td>" +
      listaDeMiembros[i].party + "</td>" +
      " <td>" +
      listaDeMiembros[i].state + "</td> " +
      "<td>" +
      listaDeMiembros[i].seniority + "</td> " +
      " <td>" +
      listaDeMiembros[i].votes_with_party_pct + "%" + "</td></tr>"
  }
  return listaFinal;
}

//Filtro la informacion a los checkboxes y al menu desplegable
function filtrarTabla(listaDeMiembros) {
  var tablaFiltrada = [];
  var estadoSeleccionado = document.getElementById('estados').value;
  var partidos = Array.from(document.querySelectorAll("input[name=partido]:checked")).map(el => el.value);
  if (partidos.length > 0) {
    for (i = 0; i < listaDeMiembros.length; i++) {
      if ((partidos.indexOf(membersHouse[i].party) >= 0) && (estadoSeleccionado == membersHouse[i].state || estadoSeleccionado == "all")) {
        tablaFiltrada.push(membersHouse[i])
      }
    }
    imprimirTabla(tablaFiltrada);
  } else {
    document.getElementById("house-data").innerHTML = "SELECT A PARTY";
  };
}

document.getElementById("house-data").innerHTML = filtrarTabla(membersHouse);

//busco los estados repetidos
var mHouse = membersHouse.length;
var listaDeEstados = new Array(mHouse);
for (i = 0; i < mHouse; i++) {
  listaDeEstados[i] = membersHouse[i].state;
}

var arrayNoRepetidos = [];
var arrayTemporal = [];

listaDeEstados.forEach((value, index) => {
  arrayTemporal = Object.assign([], listaDeEstados); //Copiado de elemento
  arrayTemporal.splice(index, 1); //Se elimina el elemnto q se compara
  /**
   * Se busca en temporal el elemento, y en repetido para
   * ver si esta ingresado al array. indexOf returna
   * -1 si el elemento no se encuetra
   **/
  if (arrayTemporal.indexOf(value) != -1 && arrayNoRepetidos.indexOf(value) == -1) arrayNoRepetidos.push(value);
});
console.log (arrayNoRepetidos);


//Dibujo los option para el selected
function menuDesplegable(estadosNoRepetidos) {
  var states = "";

  for (i = 0; i < estadosNoRepetidos.length; i++) {
    states +=
      "<option value=" + estadosNoRepetidos[i] + ">" + estadosNoRepetidos[i] + "</option>"
  }
  return states;
}
document.getElementById("estados").innerHTML += menuDesplegable(arrayNoRepetidos);


 document.getElementById("house-data").innerHTML = imprimirTabla(membersHouse);

 function vermas(id) {
   if (id == "mas") {
     document.getElementById("desplegar").style.display = "block";
     document.getElementById("mas").style.display = "none";
   } else {
     document.getElementById("desplegar").style.display = "none";
     document.getElementById("mas").style.display = "inline";
   }
 }
