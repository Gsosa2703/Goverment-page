var statistic = {
  "numberOfDemocrat": [],
  "numberOfRepublican": [],
  "numberOfIndependent": [],
  "totalPercentI": 0,
  "totalPercentR": 0,
  "totalPercentD": 0,
  "membersLeastLoyal": [],
  "membersMostLoyal": []

}

var miembros = datos.results[0].members;

//Con esto cree un array por cada partido
function buscandoCadaPartido(listaDeMiembros) {

  var partidoR = listaDeMiembros.filter((x) => (x.party === "R"));
  var partidoD = listaDeMiembros.filter((x) => (x.party === "D"));
  var partidoI = listaDeMiembros.filter((x) => (x.party === "I"));
  return {
    partidoR: partidoR,
    partidoD: partidoD,
    partidoI: partidoI
  }
}


var partidosFiltrados = buscandoCadaPartido(miembros);
statistic.numberOfDemocrat = partidosFiltrados.partidoR;
statistic.numberOfRepublican = partidosFiltrados.partidoD;
statistic.numberOfIndependent = partidosFiltrados.partidoI;

// Promedio de todos los partidos

function votosPromedio(partidos) {
  var sumaPorcentaje = 0;
  for (i = 0; i < partidos.length; i++) {
    sumaPorcentaje += partidos[i].votes_with_party_pct;
  }
  return sumaPorcentaje / partidos.length;
}

statistic.totalPercentR = votosPromedio(partidosFiltrados.partidoR);
statistic.totalPercentD = votosPromedio(partidosFiltrados.partidoD);


// Promedio de todos los partidos

function votosPromedio(partidos) {
  var sumaPorcentaje = 0;
  for (i = 0; i < partidos.length; i++) {
    sumaPorcentaje += partidos[i].votes_with_party_pct;
  }
  return sumaPorcentaje / partidos.length;
}

statistic.totalPercentR = votosPromedio(buscandoCadaPartido(miembros).partidoR);
statistic.totalPercentD = votosPromedio(buscandoCadaPartido(miembros).partidoD);


function houseLoyalty(property) {
  var listaPartido =  "<tr>" + "<td>" + "Republican" + "</td>" + "<td>" + property.numberOfRepublican.length + "</td>" + "<td>" + property.totalPercentR + "</td>" + "</tr>" +
      "<tr>" + "<td>" + "Democrat" + "</td>" + "<td>" + property.numberOfDemocrat.length + "</td>" + "<td>" + property.totalPercentD + "</td>" + "</tr>" +
      "<tr>" + "<td>" + "Independent" + "</td>" + "<td>" + property.numberOfIndependent.length + "</td>" + "<td>" + property.totalPercentI + "</td>" + "</tr>" +
      "<tr>" + "<td>" + "Total" + "</td>" + "<td>" + (property.numberOfDemocrat.length + property.numberOfIndependent.length + property.numberOfRepublican.length) + "</td>" + "<td>" + (property.totalPercentD + property.totalPercentI + property.totalPercentR) + "</td>" + "</tr>"
  
  return listaPartido;
}

document.getElementById("house-loyalty").innerHTML += houseLoyalty(statistic);

//COMIENZO A BUSCAR EL 10% DE MAS Y MENOS LEALES
var diezPorciento = Math.round((miembros.length * 10) / 100);

var miembrosMenosComprometidos = miembros.sort(function (a, b) { //ordenamos de menor a mayor lo mas comprometidos
  return a.missed_votes_pct - b.missed_votes_pct
});

statistic.membersLeastEngaged = buscarPorcentaje(miembrosMenosComprometidos, diezPorciento);

function buscarPorcentaje(miembrosTotales, porcentaje) {
  listaComprometidos = miembrosTotales.slice(0, porcentaje);
  var ultimoValorComprometido = listaComprometidos[listaComprometidos.length - 1].missed_votes_pct;
  for (var i = porcentaje; i < miembrosTotales.length; i++) {
    if (miembros[i].missed_votes_pct === ultimoValorComprometido) {
      listaComprometidos.push(miembrosTotales[i]);
    }
  }
  return listaComprometidos
}



var miembrosMasComprometidos = miembros.sort(function (a, b) { //ordenamos de mayor a menor
  return b.missed_votes_pct - a.missed_votes_pct
});

statistic.membersMostEngaged = buscarPorcentaje(miembrosMasComprometidos, diezPorciento);

function tablaComprometidos(miembrosComprometidos) {
  var listaComprometidos = "";
  for (i = 0; i < miembrosComprometidos.length; i++) {
    listaComprometidos += "<tr>" + "<td>" + "<a href=" + miembrosComprometidos[i].url + ">" + miembrosComprometidos[i].first_name + ", " + miembrosComprometidos[i].last_name + "</a>" + "</td>" +
      "<td>" +
      miembrosComprometidos[i].missed_votes + "</td>" +
      " <td>" +
      miembrosComprometidos[i].missed_votes_pct + "%" + "</td></tr>"
  }
  return listaComprometidos;
}

document.getElementById("house-menosComprometidos").innerHTML += tablaComprometidos(statistic.membersLeastEngaged);
document.getElementById("house-masComprometidos").innerHTML += tablaComprometidos(statistic.membersMostEngaged);

