var statistic = {
  "numberOfDemocrat": [],
  "numberOfRepublican": [],
  "numberOfIndependent": [],
  "totalPercentI": 0,
  "totalPercentR": 0,
  "totalPercentD": 0,
  "membersLeastLoyal": [],
  "membersMostLoyal": []

}

console.log(statistic)
var miembros = data.results[0].members;

//Con esto cree un array por cada partido
function buscandoCadaPartido(listaDeMiembros) {

  var partidoR = listaDeMiembros.filter((x) => (x.party === "R"));
  var partidoD = listaDeMiembros.filter((x) => (x.party === "D"));
  var partidoI = listaDeMiembros.filter((x) => (x.party === "I"));
  return {
    partidoR: partidoR,
    partidoD: partidoD,
    partidoI: partidoI
  }
}


var partidosFiltrados = buscandoCadaPartido(miembros);
statistic.numberOfDemocrat = partidosFiltrados.partidoR;
statistic.numberOfRepublican = partidosFiltrados.partidoD;
statistic.numberOfIndependent = partidosFiltrados.partidoI;

// Promedio de todos los partidos

function votosPromedio(partidos) {
  var sumaPorcentaje = 0;
  for (i = 0; i < partidos.length; i++) {
    sumaPorcentaje += partidos[i].votes_with_party_pct;
  }
  return sumaPorcentaje / partidos.length;
}

statistic.totalPercentR = votosPromedio(partidosFiltrados.partidoR);
statistic.totalPercentD = votosPromedio(partidosFiltrados.partidoD);
statistic.totalPercentI = votosPromedio(partidosFiltrados.partidoI);

//DIBUJO LA TABLA DE PARTIDOS



 function senateLoyalty (property) {
 
   var listaPartido = "<tr>" + "<td>"+ "Republican" + "</td>" + "<td>"+ property.numberOfRepublican.length + "</td>" + "<td>"+ property.totalPercentR+ "</td>"+ "</tr>" +
      "<tr>" + "<td>"+ "Democrat" + "</td>" + "<td>"+ property.numberOfDemocrat.length + "</td>" + "<td>"+ property.totalPercentD+ "</td>"+ "</tr>" +
      "<tr>" + "<td>"+ "Independent" + "</td>" + "<td>"+ property.numberOfIndependent.length + "</td>" + "<td>"+ property.totalPercentI+ "</td>"+ "</tr>" +
     "<tr>" + "<td>"+ "Total" + "</td>" + "<td>"+ (property.numberOfDemocrat.length+property.numberOfIndependent.length+property.numberOfRepublican.length) + "</td>" + "<td>"+ (property.totalPercentD+property.totalPercentI+property.totalPercentR)+ "</td>"+ "</tr>"
   
  return listaPartido;
}

document.getElementById("senate-loyalty").innerHTML += senateLoyalty(statistic);

//COMIENZO A BUSCAR EL 10% DE MAS Y MENOS LEALES
var diezPorciento = Math.round((miembros.length * 10) / 100);


var miembrosMenores = miembros.sort(function (a, b) { //ordenamos de menor a mayor
        return a.votes_with_party_pct - b.votes_with_party_pct
    });

//BUSCAR EL PORCENTAJE DEL ARRAY ORDENADO
function buscarDiezPorciento (array, porcentaje) {
    listaLeales = array.slice(0, porcentaje  );
    var ultimoValorLeal = listaLeales[listaLeales.length - 1].votes_with_party_pct; 
    for (var i = porcentaje; i < array.length; i++) {
        if (miembros[i].votes_with_party_pct === ultimoValorLeal) {
            listaLeales.push(array[i]);
        }
    }
  return listaLeales
}

  statistic.membersLeastLoyal= buscarDiezPorciento(miembrosMenores, diezPorciento);

var miembrosMayores = miembros.sort(function (a, b) { //ordenamos de mayor a menor
        return b.votes_with_party_pct - a.votes_with_party_pct
    });

 statistic.membersMostLoyal = buscarDiezPorciento(miembrosMayores, diezPorciento);

function tablaLeales(miembrosLeales) {
  var listaLeales = "";
  for (i = 0; i < miembrosLeales.length; i++) {
    listaLeales += "<tr>" + "<td>" + "<a href=" + miembrosLeales[i].url + ">" + miembrosLeales[i].first_name + ", " + miembrosLeales[i].last_name + "</a>" + "</td>" +
      "<td>" +
      miembrosLeales[i].total_votes + "</td>" +
      " <td>" +
      miembrosLeales[i].votes_with_party_pct + "%" + "</td></tr>"
  }
  return listaLeales;
}

document.getElementById("senate-menosLeales").innerHTML += tablaLeales(statistic.membersLeastLoyal);
document.getElementById("senate-masLeales").innerHTML += tablaLeales(statistic.membersMostLoyal);
