var miembros = data.results[0].members;

imprimirTabla(miembros);
function imprimirTabla(listaDeMiembros) {
  document.getElementById("senate-data").innerHTML = tablaSenado(listaDeMiembros);
}

//Dibujo la tabla 
function tablaSenado(listaDeMiembros) {
  var listaFinal = "";
  for (i = 0; i < listaDeMiembros.length; i++) {
    listaFinal += "<tr>" + "<td>" + i + "</td>" + "<td>" + "<a href=" + listaDeMiembros[i].url + ">" + listaDeMiembros[i].first_name + ", " + listaDeMiembros[i].last_name + "</a>" + "</td>" +
      "<td>" +
      listaDeMiembros[i].party + "</td>" +
      " <td>" +
      listaDeMiembros[i].state + "</td> " +
      "<td>" +
      listaDeMiembros[i].seniority + "</td> " +
      " <td>" +
      listaDeMiembros[i].votes_with_party_pct + "%" + "</td></tr>"
  }
  return listaFinal;
}

//Filtro la informacion a los checkboxes y al menu desplegable
function filtrarTabla(listaDeMiembros) {
  var tablaFiltrada = [];
  var estadoSeleccionado = document.getElementById('estados').value;
  var partidos = Array.from(document.querySelectorAll("input[name=partido]:checked")).map(el => el.value);
  if (partidos.length > 0) {
    for (i = 0; i < listaDeMiembros.length; i++) {
      if ((partidos.indexOf(miembros[i].party) >= 0) && (estadoSeleccionado == miembros[i].state || estadoSeleccionado == "all")) {
        tablaFiltrada.push(miembros[i])
      }
    }
    imprimirTabla(tablaFiltrada);
  } else {
    document.getElementById("senate-data").innerHTML = "SELECT A PARTY";
  };
}

document.getElementById("senate-data").innerHTML = filtrarTabla(miembros);

//busco los estados repetidos
var members = miembros.length;
var estados = new Array(members);
for (i = 0; i < members; i++) {
  estados[i] = miembros[i].state;
}

var noRepetidos = [];
var temporal = [];

estados.forEach((value, index) => {
  temporal = Object.assign([], estados); //Copiado de elemento
  temporal.splice(index, 1); //Se elimina el elemnto q se compara
  /**
   * Se busca en temporal el elemento, y en repetido para
   * ver si esta ingresado al array. indexOf returna
   * -1 si el elemento no se encuetra
   **/
  if (temporal.indexOf(value) != -1 && noRepetidos.indexOf(value) == -1) noRepetidos.push(value);
});

//Dibujo los option para el selected
function menuDesplegable(estadosNoRepetidos) {
  var states = "";

  for (i = 0; i < estadosNoRepetidos.length; i++) {
    states +=
      "<option value=" + estadosNoRepetidos[i] + ">" + estadosNoRepetidos[i] + "</option>"
  }
  return states;
}
document.getElementById("estados").innerHTML += menuDesplegable(noRepetidos);
